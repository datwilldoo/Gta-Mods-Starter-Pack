using GTA;
using GTA.Native;
using GTA.Math;
using System;
using System.Collections.Generic;
using System.Windows.Forms;

public class QuickChat : Script
{
    private Random rand = new Random();

    // Возможные ответные реплики игрока
    private readonly List<string> playerResponses = new List<string>
    {
        "Yeah i got you",
        "Talk soon",
        "Sure",
        "Alright",
        "I remember you!",
        "Its you?",
        "Thats true",
        "Pff",
        "Yea yea"
    };

    public QuickChat()
    {
        KeyDown += OnKeyDown;
    }

    private void OnKeyDown(object sender, KeyEventArgs e)
    {
        if (e.KeyCode == Keys.U)
        {
            Ped player = Game.Player.Character;

            // Находим ближайшего NPC
            Ped nearestPed = GetNearestPed(player.Position, 10f);

            if (nearestPed != null && nearestPed != player && nearestPed.IsAlive)
            {
                // NPC произносит фразу "через дорогу"
                Function.Call(Hash._PLAY_AMBIENT_SPEECH1, nearestPed.Handle, "CHAT_ACROSS_STREET_STATE", "SPEECH_PARAMS_FORCE_NORMAL_CLEAR", 0);
                UI.Notify("~y~NPC said: ~w~Hey!");

                // Небольшая задержка перед ответом игрока
                Wait(3500);

                // Выбираем случайную реплику игрока
                string reply = playerResponses[rand.Next(playerResponses.Count)];

                // Игрок отвечает с фразой
                Function.Call(Hash._PLAY_AMBIENT_SPEECH1, player.Handle, "CHAT_ACROSS_STREET_RESP", "SPEECH_PARAMS_FORCE_NORMAL_CLEAR", 0);

                // Показываем текст ответа игрока на экране
                UI.Notify("~b~You responded: ~w~" + reply);
            }
            else
            {
                UI.Notify("There are no NPCs around.");
            }
        }
    }

    private Ped GetNearestPed(Vector3 fromPos, float radius)
    {
        Ped nearestPed = null;
        float nearestDist = radius;

        foreach (Ped ped in World.GetAllPeds())
        {
            if (ped.IsHuman && !ped.IsPlayer && ped.IsAlive)
            {
                float dist = ped.Position.DistanceTo(fromPos);
                if (dist < nearestDist)
                {
                    nearestDist = dist;
                    nearestPed = ped;
                }
            }
        }

        return nearestPed;
    }
}
