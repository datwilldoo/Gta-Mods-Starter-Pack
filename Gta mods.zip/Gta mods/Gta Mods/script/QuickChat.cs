using GTA;
using GTA.Native;
using GTA.Math;
using System;
using System.Collections.Generic;
using System.Windows.Forms;

public class QuickChat : Script
{
    private Random rand = new Random();

    // Возможные ответные реплики NPC
    private readonly List<string> npcResponses = new List<string>
    {
        "Yeah i got you",
        "Talk soon",
        "Sure",
        "Alright",
        "I remember you!",
        "Its you?",
        "Thats true",
        "Pff",
        "Yea yea"
    };

    public QuickChat()
    {
        KeyDown += OnKeyDown;
    }

    private void OnKeyDown(object sender, KeyEventArgs e)
    {
        if (e.KeyCode == Keys.Y)
        {
            Ped player = Game.Player.Character;

            // Игрок произносит фразу "через дорогу"
            Function.Call(Hash._PLAY_AMBIENT_SPEECH1, player.Handle, "CHAT_ACROSS_STREET_STATE", "SPEECH_PARAMS_FORCE_NORMAL_CLEAR", 0);
            UI.Notify("~b~You said: ~w~Hey!");

            // Находим ближайшего NPC
            Ped nearestPed = GetNearestPed(player.Position, 10f);

            if (nearestPed != null && nearestPed != player && nearestPed.IsAlive)
            {


                // Небольшая задержка перед ответом
                Wait(3500);

                // Выбираем случайную реплику
                string reply = npcResponses[rand.Next(npcResponses.Count)];

                // NPC произносит игровую звуковую реплику
                Function.Call(Hash._PLAY_AMBIENT_SPEECH1, nearestPed.Handle, "CHAT_ACROSS_STREET_RESP", "SPEECH_PARAMS_FORCE_SHOUTED", 0);

                // Показываем текст ответа на экране
                UI.Notify("~y~NPC response: ~w~" + reply);
            }
            else
            {
                UI.Notify("Theres are no NPC around");
            }
        }
    }

    private Ped GetNearestPed(Vector3 fromPos, float radius)
    {
        Ped nearestPed = null;
        float nearestDist = radius;

        foreach (Ped ped in World.GetAllPeds())
        {
            if (ped.IsHuman && !ped.IsPlayer && ped.IsAlive)
            {
                float dist = ped.Position.DistanceTo(fromPos);
                if (dist < nearestDist)
                {
                    nearestDist = dist;
                    nearestPed = ped;
                }
            }
        }

        return nearestPed;
    }
}
