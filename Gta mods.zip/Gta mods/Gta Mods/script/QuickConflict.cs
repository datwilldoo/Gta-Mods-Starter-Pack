using GTA;
using GTA.Native;
using GTA.Math;
using System;
using System.Collections.Generic;
using System.Windows.Forms;

public class QuickChat : Script
{
    private Random rand = new Random();

    // Возможные оскорбления игрока
    private readonly List<string> playerInsults = new List<string>
    {
        "All i see on you is yellow",
        "Staring on me dick hole?",
        "Die asshole!",
        "You should run while you had a chance",
        "Scum of the earth!",
        "You're nothing but a joke!"
    };

    // Ответные извинения NPC
    private readonly List<string> npcApologies = new List<string>
    {
        "Who are you to judge?",
        "Screw you!",
        "You ain't on my level kid",
        "Moron!",
        "What did you say?!",
        "Do you wanna die or something?"
    };

    private int insultCount = 0; // Счётчик оскорблений

    public QuickChat()
    {
        KeyDown += OnKeyDown;
    }

    private void OnKeyDown(object sender, KeyEventArgs e)
    {
        if (e.KeyCode == Keys.N)
        {
            Ped player = Game.Player.Character;

            // Находим ближайшего NPC
            Ped nearestPed = GetNearestPed(player.Position, 10f);

            if (nearestPed != null && nearestPed != player && nearestPed.IsAlive)
            {
                if (insultCount < 3)
                {
                    // Игрок произносит оскорбление
                    string insult = playerInsults[rand.Next(playerInsults.Count)];
                    Function.Call(Hash._PLAY_AMBIENT_SPEECH1, player.Handle, "GENERIC_INSULT_HIGH", "SPEECH_PARAMS_FORCE_NORMAL_CLEAR", 0);
                    UI.Notify("~b~You insulted: ~w~" + insult);

                    // Задержка перед реакцией NPC
                    Wait(2000);

                    // NPC извиняется
                    string apology = npcApologies[rand.Next(npcApologies.Count)];
                    Function.Call(Hash._PLAY_AMBIENT_SPEECH1, nearestPed.Handle, "GENERIC_INSULT_HIGH", "SPEECH_PARAMS_FORCE_NORMAL_CLEAR", 0);
                    UI.Notify("~y~NPC apologized: ~w~" + apology);

                    insultCount++;
                }
                else
                {
                    // После третьего оскорбления NPC реагирует
                    int chance = rand.Next(100); // Случайное число от 0 до 99

                    if (chance < 20)
                    {
                        // 20% шанс, что NPC убегает
                        Function.Call(Hash._PLAY_AMBIENT_SPEECH1, nearestPed.Handle, "APOLOGY_NO_TROUBLE", "SPEECH_PARAMS_FORCE_SHOUTED", 0);
                        nearestPed.Task.ReactAndFlee(player);
                        UI.Notify("~y~NPC got scared and ran away!");
                    }
                    else
                    {
                        // 80% шанс, что NPC нападает
                        Function.Call(Hash._PLAY_AMBIENT_SPEECH1, nearestPed.Handle, "CHALLENGE_ACCEPTED_GENERIC", "SPEECH_PARAMS_FORCE_SHOUTED", 0);
                        nearestPed.Task.FightAgainst(player);
                        UI.Notify("~r~NPC has had enough!");
                    }

                    insultCount = 0; // Сброс счётчика для следующего NPC
                }
            }
            else
            {
                UI.Notify("There are no NPCs around.");
            }
        }
    }

    private Ped GetNearestPed(Vector3 fromPos, float radius)
    {
        Ped nearestPed = null;
        float nearestDist = radius;

        foreach (Ped ped in World.GetAllPeds())
        {
            if (ped.IsHuman && !ped.IsPlayer && ped.IsAlive)
            {
                float dist = ped.Position.DistanceTo(fromPos);
                if (dist < nearestDist)
                {
                    nearestDist = dist;
                    nearestPed = ped;
                }
            }
        }

        return nearestPed;
    }
}
